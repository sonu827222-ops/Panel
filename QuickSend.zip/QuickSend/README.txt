Quick Send - build steps
1. Install Android Studio, choose File > Open, select this QuickSend folder.
2. Let Gradle sync, plug in your phone (USB debugging on), press Run.
3. Open the app, edit your saved messages, press Save.
4. Press "Enable Quick Send", turn it on in Accessibility settings.
5. Open your chat app, tap the chat box, then tap a button in the floating panel.

Notes: the "Send" button is found by its label containing the word "send".
If your chat app uses an icon with no label, tap send yourself or edit findSendButton().

New in v2:
- "Auto send: N chars" button cycles OFF,1..6. Type N characters on the keyboard and the message is sent automatically.
- "Delay" button cycles 100/250/500/1000 ms (wait after the last key before sending).
- "Send next saved" and "Send random" buttons.
