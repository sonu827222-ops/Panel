package com.example.quicksend

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/** Edit your saved messages (one per line) and open Accessibility settings. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("qs", MODE_PRIVATE)

        val info = TextView(this).apply { text = "Saved messages (one per line):" }
        val edit = EditText(this).apply {
            setText(prefs.getString("msgs", "1\n2\n3\nHello\nThanks"))
            minLines = 6
        }
        val save = Button(this).apply {
            text = "Save"
            setOnClickListener { prefs.edit().putString("msgs", edit.text.toString()).apply() }
        }
        val access = Button(this).apply {
            text = "Enable Quick Send (Accessibility)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 40, 40, 40)
            addView(info); addView(edit); addView(save); addView(access)
        })
    }
}
