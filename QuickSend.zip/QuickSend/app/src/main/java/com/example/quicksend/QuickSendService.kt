package com.example.quicksend

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast

/**
 * Floating quick-send panel.
 *  - Auto N: after you type N characters, waits `delayMs` after the last key, then taps Send.
 *  - Next saved / Random / saved-message buttons: type the message and tap Send.
 */
class QuickSendService : AccessibilityService() {

    private var panel: LinearLayout? = null
    private var expanded = true
    private var autoN = 0                       // 0 = off, 1..6
    private val delays = intArrayOf(100, 250, 500, 1000)
    private var delayIdx = 1
    private var nextIdx = 0
    private var msgs: List<String> = emptyList()
    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        buildPanel()
    }

    private fun buildPanel() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        panel?.let { wm.removeView(it) }

        msgs = getSharedPreferences("qs", MODE_PRIVATE)
            .getString("msgs", "1\n2\n3\nHello\nThanks")!!
            .lines().filter { it.isNotBlank() }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xCC222222.toInt())
        }
        root.addView(Button(this).apply {
            text = "Hide/Show"
            setOnClickListener {
                expanded = !expanded
                for (i in 1 until root.childCount)
                    root.getChildAt(i).visibility = if (expanded) View.VISIBLE else View.GONE
            }
        })
        lateinit var autoBtn: Button
        autoBtn = Button(this).apply {
            text = autoLabel()
            setOnClickListener { autoN = (autoN + 1) % 7; text = autoLabel() }
        }
        root.addView(autoBtn)
        lateinit var delayBtn: Button
        delayBtn = Button(this).apply {
            text = "Delay: ${delays[delayIdx]} ms"
            setOnClickListener {
                delayIdx = (delayIdx + 1) % delays.size
                text = "Delay: ${delays[delayIdx]} ms"
            }
        }
        root.addView(delayBtn)
        root.addView(Button(this).apply {
            text = "Send next saved"
            setOnClickListener {
                if (msgs.isNotEmpty()) { send(msgs[nextIdx % msgs.size]); nextIdx++ }
            }
        })
        root.addView(Button(this).apply {
            text = "Send random"
            setOnClickListener { if (msgs.isNotEmpty()) send(msgs.random()) }
        })
        root.addView(Button(this).apply {
            text = "Reload"
            setOnClickListener { buildPanel() }
        })
        msgs.forEach { m ->
            root.addView(Button(this).apply {
                text = m
                setOnClickListener { send(m) }
            })
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            // NOT_FOCUSABLE so the chat input keeps focus while you tap our buttons
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; y = 200 }

        wm.addView(root, lp)
        panel = root
    }

    private fun autoLabel() = if (autoN == 0) "Auto send: OFF" else "Auto send: $autoN chars"

    // Fires on every text change in any app; only acts when Auto N is on.
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (autoN == 0 || event?.eventType != AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) return
        if (event.packageName == packageName) return
        val len = event.text?.joinToString("")?.length ?: 0
        handler.removeCallbacks(autoSend)
        if (len >= autoN) handler.postDelayed(autoSend, delays[delayIdx].toLong())
    }

    private val autoSend = Runnable {
        val input = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return@Runnable
        if ((input.text?.length ?: 0) >= autoN) findSendButton(rootInActiveWindow)
            ?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun send(message: String) {
        val input = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (input == null) {
            toast("Tap the chat box first")
            return
        }
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, message)
        }
        input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)

        val sendBtn = findSendButton(rootInActiveWindow)
        if (sendBtn != null) sendBtn.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        else toast("Send button not found - tap it yourself")
    }

    private fun findSendButton(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        val label = (node.contentDescription ?: node.text)?.toString()?.lowercase()
        if (node.isClickable && label != null && label.contains("send")) return node
        for (i in 0 until node.childCount) findSendButton(node.getChild(i))?.let { return it }
        return null
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onInterrupt() {}
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        panel?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        super.onDestroy()
    }
}
